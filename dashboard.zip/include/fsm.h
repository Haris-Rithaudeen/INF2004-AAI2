#pragma once
void fsm_init(void);
void fsm_step(void);
